
const passwordScreen = document.getElementById("password-screen");
const book = document.getElementById("book");
const editor = document.getElementById("editor");
const journalList = document.getElementById("journal-list");
const pageTitleInput = document.getElementById("page-title");
const pageContentInput = document.getElementById("page-content");

const PASSWORD = "aqxhjiln";

let pages = JSON.parse(localStorage.getItem("journalPages")) || [];

function checkPassword() {
  const input = document.getElementById("password").value;
  if (input === PASSWORD) {
    passwordScreen.style.display = "none";
    book.style.display = "block";
    renderList();
  } else {
    alert("Wrong password!");
  }
}

function renderList() {
  journalList.innerHTML = "";
  pages.forEach((page, index) => {
    const li = document.createElement("li");
    li.textContent = page.title;
    li.onclick = () => showPage(index);
    journalList.appendChild(li);
  });
}

function showPage(index) {
  pageTitleInput.value = pages[index].title;
  pageContentInput.value = pages[index].content;
  editor.style.display = "block";
}

function closeEditor() {
  editor.style.display = "none";
}

function addPage() {
  pageTitleInput.value = "";
  pageContentInput.value = "";
  editor.style.display = "block";
}

function savePage() {
  const title = pageTitleInput.value;
  const content = pageContentInput.value;
  if (!title.trim()) return alert("Title cannot be empty");

  const existingIndex = pages.findIndex(p => p.title === title);
  if (existingIndex >= 0) {
    pages[existingIndex].content = content;
  } else {
    pages.push({ title, content });
  }

  localStorage.setItem("journalPages", JSON.stringify(pages));
  editor.style.display = "none";
  renderList();
}
